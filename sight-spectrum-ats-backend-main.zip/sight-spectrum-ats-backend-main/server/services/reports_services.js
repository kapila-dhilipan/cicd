const fast_connection = require("../connections/fastconnection");
const mongoose = require('mongoose');


class reports_servies {
  
static async get_AM_WithSubmissions(timeRange, searchValue, start_date, end_date) {
  try {

    console.log(start_date, end_date, "date"); // Log start_date and end_date for debugging

    // Add validation and conversion logic for dates
    let startDate = start_date instanceof Date ? start_date : null;
    let endDate = end_date instanceof Date ? end_date : null;

    console.log(startDate,endDate,"check date")

    const employees = await fast_connection.models.employee
    .find({
      is_deleted: false,
      role: "account_manager",
      $or: [
        { "email": { $regex: new RegExp(searchValue, 'i') } },
        { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
        { "first_name": { $regex: new RegExp(searchValue, 'i') } },
        { "last_name": { $regex: new RegExp(searchValue, 'i') } },
        { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
        // { "reports_to": { $in: [mongoose.Types.ObjectId(searchValue)] } }, // Assuming searchValue is the ObjectId of the report_to

      ],
    })
    .select("_id employee_id first_name last_name email mobile_number role status ")
    .populate({
      path: "reports_to",
      select: ["first_name", "last_name", "employee_id"],
    });
  

    const employeeSubmissions = await Promise.all(
      employees.map(async (employee) => {
        let startDate, endDate;
       
       
        if (start_date && end_date) {
          console.log(start_date,end_date,"steddate")
          startDate = start_date;
          endDate = end_date;
      }else{
        switch (timeRange) {
          case "today":
            startDate = new Date();
            startDate.setUTCHours(0, 0, 0, 0);
            endDate = new Date();
            endDate.setUTCHours(23, 59, 59, 999);
            break;
          case "last_week":
            startDate = new Date();
            startDate.setDate(startDate.getDate() - 7);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_month":
            startDate = new Date();
            startDate.setMonth(startDate.getMonth() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_year":
            startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          default:
            startDate = null;
            endDate = new Date();
            break;
        }
      }
        let submissionsQuery = {
          is_deleted: false,
          submitted_by: employee._id,
        };

        if (startDate && endDate) {
          submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
        }

        const submissions = await fast_connection.models.submission
          .find(submissionsQuery)
          .select("approval createdAt");

        const pipeline = [
          { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
          {
            $graphLookup: {
              from: 'employees',
              startWith: '$_id',
              connectFromField: '_id',
              connectToField: 'reports_to',
              as: 'subordinates',
              maxDepth: 10,
              restrictSearchWithMatch: { is_deleted: false },
            },
          },
          {
            $facet: {
              submission_results: [
                {
                  $lookup: {
                    from: 'submissions',
                    let: { subordinateIds: '$subordinates._id' },
                    pipeline: [
                      {
                        $match: {
                          $expr: {
                            $and: [
                              { $in: ['$submitted_by', '$$subordinateIds'] },
                              { $eq: ['$is_deleted', false] },
                            ],
                          },
                        },
                      },
                    ],
                    as: 'subordinate_submissions',
                  },
                },
                { $unwind: { path: '$subordinate_submissions', preserveNullAndEmptyArrays: true } },
                {
                  $group: {
                    _id: '$_id',
                    subordinates: { $first: '$subordinates' },
                    subordinate_submissions: { $push: '$subordinate_submissions' },
                  },
                },
              ],
            },
          },
        ];

        const results = await fast_connection.models.employee.aggregate(pipeline);

        const submission_results = results[0].submission_results;
        const sub_submission = submission_results[0].subordinate_submissions;

        const todaySubmissions = startDate && endDate ?
          sub_submission.filter(submission => {
            const createdAtDate = new Date(submission.createdAt);
            return createdAtDate >= startDate && createdAtDate <= endDate;
          }) :
          sub_submission;

        const sub_teamCount = todaySubmissions.length;
        const submissionsCount = submissions.length;

        return { employee, submissionsCount, sub_teamCount };
      })
    );

    return employeeSubmissions;
  } catch (error) {
    throw error;
  }
}




static async get_TL_WithSubmissions(timeRange,searchValue, start_date, end_date) {
  try {
    const employees = await fast_connection.models.employee
    .find({
      is_deleted: false,
      role: "team_lead",
      $or: [
        { "email": { $regex: new RegExp(searchValue, 'i') } },
        { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
        { "first_name": { $regex: new RegExp(searchValue, 'i') } },
        { "last_name": { $regex: new RegExp(searchValue, 'i') } },
        { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
        
      ],
    })
    .select("_id employee_id first_name last_name email mobile_number role status ")
    .populate({
      path: "reports_to",
      select: ["first_name", "last_name", "employee_id"],
    });
  

    const employeeSubmissions = await Promise.all(
      employees.map(async (employee) => {
        let startDate, endDate;

        if (start_date && end_date) {
          console.log(start_date,end_date,"steddate")
          startDate = start_date;
          endDate = end_date;
      }else{
        switch (timeRange) {
          case "today":
            startDate = new Date();
            startDate.setUTCHours(0, 0, 0, 0);
            endDate = new Date();
            endDate.setUTCHours(23, 59, 59, 999);
            break;
          case "last_week":
            startDate = new Date();
            startDate.setDate(startDate.getDate() - 7);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_month":
            startDate = new Date();
            startDate.setMonth(startDate.getMonth() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          case "last_year":
            startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 1);
            endDate = new Date().setUTCHours(23, 59, 59, 999);
            break;
          default:
            startDate = null;
            endDate = new Date();
            break;
        }
      }

        let submissionsQuery = {
          is_deleted: false,
          submitted_by: employee._id,
        };

        if (startDate && endDate) {
          submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
        }

        const submissions = await fast_connection.models.submission
          .find(submissionsQuery)
          .select("approval createdAt");

        const pipeline = [
          { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
          {
            $graphLookup: {
              from: 'employees',
              startWith: '$_id',
              connectFromField: '_id',
              connectToField: 'reports_to',
              as: 'subordinates',
              maxDepth: 10,
              restrictSearchWithMatch: { is_deleted: false },
            },
          },
          {
            $facet: {
              submission_results: [
                {
                  $lookup: {
                    from: 'submissions',
                    let: { subordinateIds: '$subordinates._id' },
                    pipeline: [
                      {
                        $match: {
                          $expr: {
                            $and: [
                              { $in: ['$submitted_by', '$$subordinateIds'] },
                              { $eq: ['$is_deleted', false] },
                            ],
                          },
                        },
                      },
                    ],
                    as: 'subordinate_submissions',
                  },
                },
                { $unwind: { path: '$subordinate_submissions', preserveNullAndEmptyArrays: true } },
                {
                  $group: {
                    _id: '$_id',
                    subordinates: { $first: '$subordinates' },
                    subordinate_submissions: { $push: '$subordinate_submissions' },
                  },
                },
              ],
            },
          },
        ];

        const results = await fast_connection.models.employee.aggregate(pipeline);

        const submission_results = results[0].submission_results;
        const sub_submission = submission_results[0].subordinate_submissions;

        const todaySubmissions = startDate && endDate ?
          sub_submission.filter(submission => {
            const createdAtDate = new Date(submission.createdAt);
            return createdAtDate >= startDate && createdAtDate <= endDate;
          }) :
          sub_submission;

        const sub_teamCount = todaySubmissions.length;
        const submissionsCount = submissions.length;

        return { employee, submissionsCount, sub_teamCount };
      })
    );

    return employeeSubmissions;
  } catch (error) {
    throw error;
  }
        }
        
        static async getRecruitersWithSubmissions(timeRange,searchValue, start_date, end_date) {
          try {
            const employees = await fast_connection.models.employee
              .find({
                is_deleted: false,
                role: "recruiter",
                $or: [
                  { "email": { $regex: new RegExp(searchValue, 'i') } },
                  { "employee_id": { $regex: new RegExp(searchValue, 'i') } },
                  { "first_name": { $regex: new RegExp(searchValue, 'i') } },
                  { "last_name": { $regex: new RegExp(searchValue, 'i') } },
                  { "mobile_number": { $regex: new RegExp(searchValue, 'i') } },
                ],
              })
              .select("_id employee_id first_name last_name email mobile_number role status ")
              .populate({
                path: "reports_to",
                select: ["first_name", "last_name", "employee_id"],
              });
        
            const employeeSubmissions = await Promise.all(
              employees.map(async (employee) => {
                let startDate, endDate;
               
                if (start_date && end_date) {
                  console.log(start_date,end_date,"steddate")
                  startDate = start_date;
                  endDate = end_date;
              }else{
                switch (timeRange) {
                  case "today":
                    startDate = new Date();
                    startDate.setHours(0, 0, 0, 0);
                    endDate = new Date();
                    endDate.setHours(23, 59, 59, 999);
                    break;
                  case "last_week":
                    startDate = new Date();
                    startDate.setDate(startDate.getDate() - 7);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_month":
                    startDate = new Date();
                    startDate.setMonth(startDate.getMonth() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_year":
                    startDate = new Date();
                    startDate.setFullYear(startDate.getFullYear() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  default:
                    startDate = null;
                    endDate = new Date();
                    break;
                }
              }
        
                let submissionsQuery = {
                  is_deleted: false,
                  submitted_by: employee._id,
                };
        
                if (startDate && endDate) {
                  submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
                }
        
                const submissions = await fast_connection.models.submission
                  .find(submissionsQuery)
                  .select("approval createdAt");
        
                const submissionsCount = submissions.length;
                const approvalTrueCount = submissions.filter(submission => submission.approval === true).length;
                const approvalFalseCount = submissions.filter(submission => submission.approval === false).length;
        
                return { employee, submissionsCount, approvalFalseCount, approvalTrueCount };
              })
            );
        
        
            return employeeSubmissions;
          } catch (error) {
            throw error;
          }
        }
  
        static async getAllroleSubmission(timeRange, searchValue, start_date, end_date) {
          try {
            const employees = await fast_connection.models.employee
              .find({
                is_deleted: false,
                role: { $in: ["recruiter", "account_manager", "team_lead"] },
                $or: [
                  { email: { $regex: new RegExp(searchValue, "i") } },
                  { employee_id: { $regex: new RegExp(searchValue, "i") } },
                  { first_name: { $regex: new RegExp(searchValue, "i") } },
                  { last_name: { $regex: new RegExp(searchValue, "i") } },
                  { mobile_number: { $regex: new RegExp(searchValue, "i") } },
                ],
              })
              .select("_id employee_id first_name last_name email mobile_number role status ")
              .populate({
                path: "reports_to",
                select: ["first_name", "last_name", "employee_id"],
              });
        
            const employeeSubmissions = await Promise.all(
              employees.map(async (employee) => {
                let startDate, endDate;
        

                if (start_date && end_date) {
                  console.log(start_date,end_date,"steddate")
                  startDate = start_date;
                  endDate = end_date;
              }else{
                switch (timeRange) {
                  case "today":
                    startDate = new Date();
                    startDate.setHours(0, 0, 0, 0);
                    endDate = new Date();
                    endDate.setHours(23, 59, 59, 999);
                    break;
                  case "last_week":
                    startDate = new Date();
                    startDate.setDate(startDate.getDate() - 7);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_month":
                    startDate = new Date();
                    startDate.setMonth(startDate.getMonth() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  case "last_year":
                    startDate = new Date();
                    startDate.setFullYear(startDate.getFullYear() - 1);
                    endDate = new Date();
                    endDate.setUTCHours(23, 59, 59, 999);
                    break;
                  default:
                    startDate = null;
                    endDate = new Date();
                    break;
                }
              }
        
                let submissionsQuery = {
                  is_deleted: false,
                  submitted_by: employee._id,
                };
        
                if (startDate && endDate) {
                  submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
                }
        
                const submissions = await fast_connection.models.submission.find(submissionsQuery).select("approval createdAt");
        
                const submissionsCount = submissions.length;
                const approvalTrueCount = submissions.filter((submission) => submission.approval === true).length;
                const approvalFalseCount = submissions.filter((submission) => submission.approval === false).length;
        
                return { employee, submissionsCount, approvalFalseCount, approvalTrueCount };
              })
            );
        
        
            return employeeSubmissions;
          } catch (error) {
            throw error;
          }
        }
        


  
 
}

module.exports = reports_servies;
