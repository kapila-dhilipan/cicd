const fast_connection = require("../connections/fastconnection");
const moment = require("moment")

class interview_services {

    static async createMeet(data) {
        try {
            const scheduleMeet = new fast_connection.models.interview(data);
            return await scheduleMeet.save();
        } catch (error) {
            throw error;
        }
    }
    static async generateMeetingID() {
        const latestMeeting = await fast_connection.models.interview
            .findOne({}, { _id: 0, MeetID: 1 }) // Assuming the field name is MeetID
            .sort({ MeetID: -1 });
        let latestCount = 0;

        if (latestMeeting && latestMeeting.MeetID) {
            latestCount = parseInt(latestMeeting.MeetID.substring(2));
        }

        const nextCount = latestCount + 1;
        const prefix = "PY";
        const paddingLength = 4;
        const paddedCount = nextCount.toString().padStart(paddingLength, '0');
        return `${prefix}${paddedCount}`;
    }

    static async listInterview({ skip, limit, sort_type, sort_field }) {
        try {
            return await fast_connection.models.interview.find({ is_deleted: false }).skip(skip).limit(limit).sort([[sort_field, sort_type]]);
        }
        catch (error) {
            throw error;
        }
    }
    static async getUserCreatedInterview(user_id, { skip, limit, sort_type, sort_field }) {
        try {
            let query = { is_deleted: false, created_by: user_id }
            return await fast_connection.models.interview.find(query).skip(skip).limit(limit).sort([[sort_field, sort_type]]);
        } catch (error) {
            throw error;
        }
    }
    static async getUserCreatedInterviews(userIdHierarchy, hierarchyUsers, { skip, limit, sort_type, sort_field }) {
        try {
            const userIds = [userIdHierarchy, ...hierarchyUsers];

            const interviews = await fast_connection.models.interview
                .find({ created_by: { $in: userIds } })
                .skip(parseInt(skip))
                .limit(parseInt(limit))
                .sort({ createdAt: -1 });

            return interviews;
        } catch (error) {
            throw error;
        }
    }
    static async getByReportsto(reports_to) {
        try {
            const allSubordinateIds = new Set();

            async function fetchSubordinates(employeeIds) {
                const subordinates = await fast_connection.models.employee
                    .find({ reports_to: { $in: employeeIds }, is_deleted: false })
                    .select('_id');

                if (subordinates.length > 0) {
                    const subordinateIds = subordinates.map(subordinate => subordinate._id);
                    subordinateIds.forEach(id => allSubordinateIds.add(id));
                    await fetchSubordinates(subordinateIds);
                }
            }

            await fetchSubordinates([reports_to]);

            return Array.from(allSubordinateIds);
        } catch (error) {
            throw error;
        }
    }
    // static async getByReportsto(id) {
    //     try {
    //         return await fast_connection.models.employee.find({ _id: id }).populate({ path: "reports_to", select: ["_id", "first_name", "last_name"] });
    //     } catch (error) {
    //         throw error;
    //     }
    // }
    // static async getByReportsto(reports_to) {
    //     try {
    //         let query = {
    //             is_deleted: false,
    //             $or: [
    //                 { reports_to: { $in: reports_to } },

    //             ]
    //         };
    //         return await fast_connection.models.employee.find(query).populate([{ path: 'reports_to', select: '_id first_name last_name' }]);

    //     } catch (error) {
    //         throw error;
    //     }
    // }

    static async getMeetStatus(id) {
        try {
            console.log(id)
            const meetStat = await fast_connection.models.interview.find({ created_by: id })
            return meetStat;
        } catch (err) {
            console.log("from service file", err)
            throw err;
        }
    }
    // static async updateInterviewStatus(interviews) {
    //     const currentTime = moment();

    //     async function updateInterview(interviewId, status) {
    //         try {
    //             await fast_connection.models.interview.findByIdAndUpdate(interviewId, { status });
    //             console.log(`Interview ${interviewId} updated to ${status}`);
    //         } catch (error) {
    //             console.error(`Error updating interview ${interviewId}:`, error);
    //         }
    //     }

    //     for (const interview of interviews) {
    //         const startDateTime = moment(interview.startDateTime);
    //         if (currentTime.isSame(startDateTime, 'minute')) {
    //             await updateInterview(interview._id, 'In Progress');
    //         } else if (currentTime.isAfter(startDateTime)) {
    //             await updateInterview(interview._id, 'Completed');
    //         }
    //         else if (currentTime.isBefore(startDateTime)) {
    //             await updateInterview(interview._id, 'Scheduled')
    //         }
    //     }

    // }

    static async updateInterviewStatus(interviews) {
        const currentTime = moment();

        async function updateInterview(interviewId, status) {
            try {
                await fast_connection.models.interview.findByIdAndUpdate(interviewId, { status });
            } catch (error) {
                console.error(`Error updating interview ${interviewId}:`, error);
            }
        }

        for (const interview of interviews) {
            const startDateTime = moment(interview.startDateTime);
            if (interview.status === "Cancelled") {
                continue; // Skip to the next iteration
            }
            if ((currentTime.isSame(startDateTime, 'minute')) && (interview.status !== "Cancelled")) {
                await updateInterview(interview._id, 'On Progress');
            } else if ((currentTime.isAfter(startDateTime)) && (interview.status !== "Cancelled")) {
                await updateInterview(interview._id, 'Completed');
            }
            else if ((currentTime.isBefore(startDateTime)) && (interview.status !== "Cancelled")) {
                if (interview.status === "Rescheduled") {
                    continue;
                } else {
                    await updateInterview(interview._id, 'Scheduled')
                }
            }
        }

    }

    static async getSearchValue(str) {
        try {
            const ar = new RegExp(`${str}`, 'i')
            console.log(ar)
            const query = {
                $or: [
                    { "MeetID": { $regex: ar } },
                    { "demand_id": { $regex: ar } },
                    { "mobile_no": { $regex: ar } },
                    { "candidate_email": { $regex: ar } },
                    { "interviewer_email": { $regex: ar } },
                    { "company_name": { $regex: ar } },
                    { "title": { $regex: ar } },
                    { "schedule_meet_id": { $regex: ar } },
                    { "passcode": { $regex: ar } },
                    { "meet_url": { $regex: ar } },
                    { "status": { $regex: ar } }
                ]
            }
            const meetStat = await fast_connection.models.interview.find(query)
            return meetStat;
        } catch (err) {
            console.log("from service file", err)
            throw err;
        }
    }
    static async updateStatus(Id, data) {
        try {
            await fast_connection.models.interview.findByIdAndUpdate(Id, data);
            console.log("Staus Updated Successfully!");
        } catch (error) {
            console.error(`Error updating interview ${interviewId}:`, error);
        }
    }
}

module.exports = interview_services;