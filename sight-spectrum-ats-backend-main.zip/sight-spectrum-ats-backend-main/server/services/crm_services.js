const fast_connection = require("../connections/fastconnection");
const mongoose=require('mongoose')
class crm_services {

    static async initializeCounter() {
        try {
            const counter = await fast_connection.models.counter.findOne({ _id: 'opportunityIdCounter' });
            if (!counter) {
                const newCounter = new fast_connection.models.counter({ _id: 'opportunityIdCounter', sequenceValue: 10080 });
                await newCounter.save();
            }
        } catch (error) {
            throw error;
        }
    }
    static async addNew(data) {
 
        try {
            const addNewDetails = new fast_connection.models.salespipelinesheet(data);
            await addNewDetails.save();
          return "Opptunity added Successfully"
        } catch (error) {
           console.log(error,'failed');
        }
    }
    static async checkClientId(clientId) {
        try {
            const client = await fast_connection.models.client.findOne({ ClientId: clientId });
            // console.log(client)
            return client;
        } catch (error) {
            throw error;
        }
    }
    static async getOpportunityDetails({ skip, limit, sort_type, sort_field }) {
        try {
            return await fast_connection.models.salespipelinesheet.find({is_deleted:false}).populate([{ path: 'request_client', select: '_id ClientId company_name' },{ path: 'assign_to', select: '_id first_name last_name' }]).skip(skip).limit(limit).sort([[sort_field, sort_type]]);
        } catch (error) {
            throw error;
        }
    }
    static async getOpportunityId() {
        try {
            return await fast_connection.models.salespipelinesheet.findOne().sort({ _id: -1 }).limit(1);
        } catch (error) {
            throw error;
        }
    }
    static async getClientById(_id) {
        try {
            return await fast_connection.models.salespipelinesheet.findById({ _id }).populate([{ path: 'request_client', select: '_id ClientId company_name' },{ path: 'assign_to', select: '_id first_name last_name' }]);
        }
        catch (error) {
            throw error;
        }
    }
    static async updateData(_id, newData) {
        try {
            return await fast_connection.models.salespipelinesheet.findByIdAndUpdate(  _id, newData,{ new: true });
        } catch (error) {
            throw error;
        }
    }
    static async deleteData(_id) {
        try {
            return await fast_connection.models.salespipelinesheet.findByIdAndDelete(_id,  { new: true });
        } catch (error) {
            throw error;
        }
    }
    static async searchClient(field_name, filed_value) {
    
        try {
            let query_obj = { is_deleted: false }
            const regex = new RegExp(filed_value, 'i');
            if (field_name === 'request_client') {
                let request_client= await fast_connection.models.salespipelinesheet.find().populate({ path: 'request_client', select: '_id ClientId company_name' });
                 const filteredDemands = request_client.filter(data => {
                    return data.request_client.company_name.match(regex)
                  });
                return filteredDemands;
            } else {
                 query_obj[field_name] = regex;
           return await fast_connection.models.salespipelinesheet.find(query_obj).populate({ path: 'request_client', select: '_id ClientId company_name' });
            }
           
           
        } catch (error) {
            throw error;
        }
    }
    static async getclientDetails() {
        try {
            const crm = await fast_connection.models.client.find({}, 'ClientId company_name');
            const clients = crm.map(client => {
            return{ 
                key: client._id.toString(),
                text: `${client.company_name} - ${client.ClientId}`
              }
            });
        
         return clients;
        } catch (error) {
          throw error;
        }
      }
      static async getclientId(id) {
        try {
          return await fast_connection.models.salespipelinesheet.find({request_client:id}).select(' _id Opportunity_id name level status updatedAt');
        } catch (error) {
            throw error;
        }
    }
}
module.exports = crm_services;
