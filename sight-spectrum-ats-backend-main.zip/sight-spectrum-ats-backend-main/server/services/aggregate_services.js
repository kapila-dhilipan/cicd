const fast_connection = require("../connections/fastconnection");
const mongoose = require("mongoose");

class aggregate_servies {
  static async get_Admin_WithSubmissions(timeRange) {
    try {
      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, role: "admin" })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; // Initialize start and end dates

          // Determine the start date based on the selected time range
          switch (timeRange) {
            case "day":
              startDate = new Date();
              startDate.setUTCHours(0, 0, 0, 0); // Start of the day
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "week":
              startDate = new Date();
              startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
              endDate = new Date().setUTCHours(23, 59, 59, 999);
              break;
            case "month":
              startDate = new Date();
              startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            case "year":
              startDate = new Date();
              startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            default:
              startDate = null; // Default to null for "Till date" or any other case
              endDate = new Date(); // Default to current date/time for other cases
              break;
          }

          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                submission_results: [
                  {
                    $lookup: {
                      from: "submissions", // Assuming 'submissions' is the collection name
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                                { $eq: ["$is_deleted", false] },
                              ],
                            },
                          },
                        },
                      ],
                      as: "subordinate_submissions",
                    },
                  },
                  { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_submissions: { $push: "$subordinate_submissions" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);

          const submission_results = results[0].submission_results;
          const sub_submission = submission_results[0].subordinate_submissions;

          const todaySubmissions =
            startDate && endDate
              ? sub_submission.filter((submission) => {
                  const createdAtDate = new Date(submission.createdAt);
                  return createdAtDate >= startDate && createdAtDate <= endDate;
                })
              : sub_submission;

          const sub_teamCount = todaySubmissions.length;

          const submissionsCount = submissions.length;

          return { employee, submissionsCount, sub_teamCount };
        })
      );

      const employeCount = employeeSubmissions.length;

      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }

  static async get_AM_WithSubmissions(timeRange) {
    try {
      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, role: "account_manager" })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; // Initialize start and end dates

          // Determine the start date based on the selected time range
          switch (timeRange) {
            case "day":
              startDate = new Date();
              startDate.setUTCHours(0, 0, 0, 0); // Start of the day
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "week":
              startDate = new Date();
              startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
              endDate = new Date().setUTCHours(23, 59, 59, 999);
              break;
            case "month":
              startDate = new Date();
              startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            case "year":
              startDate = new Date();
              startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            default:
              startDate = null; // Default to null for "Till date" or any other case
              endDate = new Date(); // Default to current date/time for other cases
              break;
          }

          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                submission_results: [
                  {
                    $lookup: {
                      from: "submissions", // Assuming 'submissions' is the collection name
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                                { $eq: ["$is_deleted", false] },
                              ],
                            },
                          },
                        },
                      ],
                      as: "subordinate_submissions",
                    },
                  },
                  { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_submissions: { $push: "$subordinate_submissions" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);

          const submission_results = results[0].submission_results;
          const sub_submission = submission_results[0].subordinate_submissions;

          const todaySubmissions =
            startDate && endDate
              ? sub_submission.filter((submission) => {
                  const createdAtDate = new Date(submission.createdAt);
                  return createdAtDate >= startDate && createdAtDate <= endDate;
                })
              : sub_submission;

          const sub_teamCount = todaySubmissions.length;

          const submissionsCount = submissions.length;

          const overallcount = sub_teamCount + submissionsCount;

          return { employee, submissionsCount, sub_teamCount, overallcount };
        })
      );
      const employeCount = employeeSubmissions.length;

      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }

  static async get_TL_WithSubmissions(timeRange) {
    try {
      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, role: "team_lead" })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; // Initialize start and end dates
          // Determine the start date based on the selected time range
          switch (timeRange) {
            case "day":
              startDate = new Date();
              startDate.setUTCHours(0, 0, 0, 0); // Start of the day
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "week":
              startDate = new Date();
              startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
              endDate = new Date().setUTCHours(23, 59, 59, 999);
              break;
            case "month":
              startDate = new Date();
              startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            case "year":
              startDate = new Date();
              startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            default:
              startDate = null; // Default to null for "Till date" or any other case
              endDate = new Date(); // Default to current date/time for other cases
              break;
          }

          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                submission_results: [
                  {
                    $lookup: {
                      from: "submissions", // Assuming 'submissions' is the collection name
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                                { $eq: ["$is_deleted", false] },
                              ],
                            },
                          },
                        },
                      ],
                      as: "subordinate_submissions",
                    },
                  },
                  { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_submissions: { $push: "$subordinate_submissions" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);

          const submission_results = results[0].submission_results;
          const sub_submission = submission_results[0].subordinate_submissions;

          const todaySubmissions =
            startDate && endDate
              ? sub_submission.filter((submission) => {
                  const createdAtDate = new Date(submission.createdAt);
                  return createdAtDate >= startDate && createdAtDate <= endDate;
                })
              : sub_submission;

          const sub_teamCount = todaySubmissions.length;

          const submissionsCount = submissions.length;
          const overallcount = sub_teamCount + submissionsCount;

          return { employee, submissionsCount, sub_teamCount, overallcount };
        })
      );
      const employeCount = employeeSubmissions.length;

      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }

  static async getRecruitersWithSubmissions(timeRange) {
    try {
      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, role: "recruiter" })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; // Initialize start and end dates

          // Determine the start date based on the selected time range
          switch (timeRange) {
            case "day":
              startDate = new Date();
              startDate.setHours(0, 0, 0, 0); // Start of the day
              endDate = new Date();
              endDate.setHours(23, 59, 59, 999); // End of the day
              break;
            case "week":
              startDate = new Date();
              startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "month":
              startDate = new Date();
              startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "year":
              startDate = new Date();
              startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            default:
              startDate = null; // Default to null for "Till date" or any other case
              endDate = new Date(); // Default to current date/time for other cases
              break;
          }

          // Filter submissions based on the time range
          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const overallcount = submissions.length;

          return { employee, overallcount };
        })
      );

      const employeCount = employeeSubmissions.length;

      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }

  static async getIndividualHierarchy(timeRange, user_id, start_date, end_date) {
    try {
      const startdate = start_date ? new Date(start_date) : null;
      const enddate = end_date ? new Date(end_date) : null;

      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, reports_to: user_id })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; 
          if (startdate && enddate) {
            console.log(startdate, enddate, "steddate");
            startDate = startdate;
            endDate = enddate;
          } else {
            switch (timeRange) {
              case "day":
                startDate = new Date();
                startDate.setUTCHours(0, 0, 0, 0); 
                endDate = new Date();
                endDate.setUTCHours(23, 59, 59, 999); 
                break;
              case "week":
                startDate = new Date();
                startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
                endDate = new Date().setUTCHours(23, 59, 59, 999);
                break;
              case "month":
                startDate = new Date();
                startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
                endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
                break;
              case "year":
                startDate = new Date();
                startDate.setFullYear(startDate.getFullYear() - 1);
                endDate = new Date().setUTCHours(23, 59, 59, 999);
                break;
              default:
                startDate = null;
                endDate = new Date();
                break;
            }
          }

          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                submission_results: [
                  {
                    $lookup: {
                      from: "submissions",
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                                { $eq: ["$is_deleted", false] },
                              ],
                            },
                          },
                        },
                      ],
                      as: "subordinate_submissions",
                    },
                  },
                  { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_submissions: { $push: "$subordinate_submissions" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);

          const submission_results = results[0].submission_results;
          const sub_submission = submission_results[0].subordinate_submissions;

          const todaySubmissions =
            startDate && endDate
              ? sub_submission.filter((submission) => {
                  const createdAtDate = new Date(submission.createdAt);
                  return createdAtDate >= startDate && createdAtDate <= endDate;
                })
              : sub_submission;

          const sub_teamCount = todaySubmissions.length;

          const submissionsCount = submissions.length;
          const overallcount = sub_teamCount + submissionsCount;

          return { employee, overallcount };
        })
      );

      const employeCount = employeeSubmissions.length;
      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }

  static async get_AM_WithSubmissions(timeRange) {
    try {
      const employees = await fast_connection.models.employee
        .find({ is_deleted: false, role: "account_manager" })
        .select("_id employee_id first_name last_name email mobile_number role status ")
        .populate({
          path: "reports_to",
          select: ["first_name", "last_name", "employee_id"],
        });

      const employeeSubmissions = await Promise.all(
        employees.map(async (employee) => {
          let startDate, endDate; // Initialize start and end dates

          // Determine the start date based on the selected time range
          switch (timeRange) {
            case "day":
              startDate = new Date();
              startDate.setUTCHours(0, 0, 0, 0); // Start of the day
              endDate = new Date();
              endDate.setUTCHours(23, 59, 59, 999); // End of the day
              break;
            case "week":
              startDate = new Date();
              startDate.setDate(startDate.getDate() - 7); // Set start date to 7 days ago
              endDate = new Date().setUTCHours(23, 59, 59, 999);
              break;
            case "month":
              startDate = new Date();
              startDate.setMonth(startDate.getMonth() - 1); // 1 month ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            case "year":
              startDate = new Date();
              startDate.setFullYear(startDate.getFullYear() - 1); // 1 year ago
              endDate = new Date().setUTCHours(23, 59, 59, 999); // Current date/time
              break;
            default:
              startDate = null; // Default to null for "Till date" or any other case
              endDate = new Date(); // Default to current date/time for other cases
              break;
          }

          let submissionsQuery = {
            is_deleted: false,
            submitted_by: employee._id,
          };

          if (startDate && endDate) {
            submissionsQuery.createdAt = { $gte: startDate, $lt: endDate };
          }

          const submissions = await fast_connection.models.submission
            .find(submissionsQuery)
            .select("approval createdAt");

          const pipeline = [
            { $match: { _id: mongoose.Types.ObjectId(employee._id), is_deleted: false } },
            {
              $graphLookup: {
                from: "employees",
                startWith: "$_id",
                connectFromField: "_id",
                connectToField: "reports_to",
                as: "subordinates",
                maxDepth: 10,
                restrictSearchWithMatch: { is_deleted: false },
              },
            },
            {
              $facet: {
                submission_results: [
                  {
                    $lookup: {
                      from: "submissions", // Assuming 'submissions' is the collection name
                      let: { subordinateIds: "$subordinates._id" },
                      pipeline: [
                        {
                          $match: {
                            $expr: {
                              $and: [
                                { $in: ["$submitted_by", "$$subordinateIds"] }, // Match based on 'submitted_by' field
                                { $eq: ["$is_deleted", false] },
                              ],
                            },
                          },
                        },
                      ],
                      as: "subordinate_submissions",
                    },
                  },
                  { $unwind: { path: "$subordinate_submissions", preserveNullAndEmptyArrays: true } },
                  {
                    $group: {
                      _id: "$_id",
                      subordinates: { $first: "$subordinates" },
                      subordinate_submissions: { $push: "$subordinate_submissions" },
                    },
                  },
                ],
              },
            },
          ];

          const results = await fast_connection.models.employee.aggregate(pipeline);

          const submission_results = results[0].submission_results;
          const sub_submission = submission_results[0].subordinate_submissions;

          const todaySubmissions =
            startDate && endDate
              ? sub_submission.filter((submission) => {
                  const createdAtDate = new Date(submission.createdAt);
                  return createdAtDate >= startDate && createdAtDate <= endDate;
                })
              : sub_submission;

          const sub_teamCount = todaySubmissions.length;

          const submissionsCount = submissions.length;

          const overallcount = sub_teamCount + submissionsCount;

          return { employee, submissionsCount, sub_teamCount, overallcount };
        })
      );
      const employeCount = employeeSubmissions.length;

      return { employeeSubmissions, employeCount };
    } catch (error) {
      throw error;
    }
  }
}

module.exports = aggregate_servies;
