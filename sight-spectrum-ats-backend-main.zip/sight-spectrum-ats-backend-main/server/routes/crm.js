const express = require("express");
const router = express.Router();
const crm_controller = require("../controllers/crm_controller");
const {mediaUploadS3} = require("../utils/s3_helper")

router.post("/addnew", crm_controller.createOpportunity.controller);
router.get("/getOpportunity", crm_controller.getOpportunityDetails .controller)
router.get("/getclientbyid/:_id", crm_controller.getOpportunityById.controller)
router.put("/updateData/:_id", crm_controller.updateClientData.controller)
router.post("/addDocuments",mediaUploadS3("crm_docs").array("files"), crm_controller.addCrmDocuments.controller)
router.post("/deleteClientData/:_id", crm_controller.deleteClientData.controller)
router.get("/searchClients", crm_controller.searchClients.controller)
router.get("/downloadClient", crm_controller.downloadClient.controller)
router.get("/getDealname", crm_controller.getclientDetails.controller)
router.get("/getadminsales", crm_controller.getAdminSales.controller)

module.exports = router;