const mongoose = require("mongoose");
const Schema = mongoose.Schema

const crm_schema = new Schema({
    Opportunity_id:{type:String,unique:true},
    name: { type: String, },
    request_type: { type: String, },
    request_client:  { type: Schema.Types.ObjectId, ref: 'client' },
    level:{ type: String, },
    status: { type: String, },
    customer_name: { type: String },
    email_id: { type: String },
    mobile_number: { type: String, },
    start_date: { type: String, },
    close_date: { type: String, },
    status: { type: String, },
    probability_winning: { type: String, },
    priority_level: { type: String, },
    opportunity_source: { type: String, },
    assign_to:  { type: Schema.Types.ObjectId, ref: 'employee' },
    region_location: { type: String, },
    ss_businness_unit: { type: String, },
    currency: { type: String, },
    opportunity_value: { type: String },
    budget_status: { type: String, },
    documents: [{type: Object}],
    created_by: { type: Schema.Types.ObjectId, ref: 'employee' },
    is_deleted: { type: Boolean, default: false },
    
    // updated_by: { type: Schema.Types.ObjectId, ref: 'employee' },

},
    {
        timestamps: true
    })



module.exports = crm_schema;