const mongoose = require("mongoose");
const Schema = mongoose.Schema

const client_schema = new Schema({
    ClientId: { type: String , unique: true},    
    company_name:  { type: String},
    empanelment:  { type: String },
    expansion:  { type: String},
    point_of_contact_name:  { type: String},
    destination:  { type: String },
    reports_to:  { type: String },
    primary_email:  { type: String },
    primary_mobile:  { type: String },
    alternate_email: { type: String },
    alternate_mobile:  { type: String },
    website:  { type: String },
    linkedin:  { type: String },
    company_address:  { type: String },
    city:  { type: String },
    pincode:  { type: String },
    passthrough:  { type: String },
    passthrough_company:{ type: String },
    passthrough_person:{ type: String },
    documents: [{ type: Object }],
    template_url: [{ type: Object }],
    created_by: { type: Schema.Types.ObjectId, ref: 'employee' },
    is_deleted: { type: Boolean, default: false }
},
    {
        timestamps: true
    });

module.exports = client_schema;
