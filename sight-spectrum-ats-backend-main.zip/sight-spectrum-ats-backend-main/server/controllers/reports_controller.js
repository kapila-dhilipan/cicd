const reports_services = require("../services/reports_services"); // Corrected import for reports_services




const Excel = require("exceljs");
const { ISOdateToCustomDate } = require("../utils/ISO_date_helper")
const crypto = require("crypto");
const fs = require("fs");

const applyStylesToWorksheet = (worksheet, excelData) => {
  const columnHeaders = excelData.client;
  const columnWidths = columnHeaders.map((header, index) => ({
    header: header,
    key: String(index + 1),
    width: 18,
  }));

  worksheet.columns = columnWidths;

  const headerRow = worksheet.getRow(1);
  headerRow.eachCell({ includeEmpty: true }, (cell) => {
    cell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'DCE6F1' },
    };
    cell.alignment = { horizontal: 'center' };
    cell.border = {
      top: { style: 'thin', color: { argb: 'B2BEB5' } },
      left: { style: 'thin', color: { argb: 'B2BEB5' } },
      bottom: { style: 'thin', color: { argb: 'B2BEB5' } },
      right: { style: 'thin', color: { argb: 'B2BEB5' } },
    };
  });

  const dataRowStartIndex = 2;
  const columnWidthPadding = 5;

  // Style for data rows
  excelData.value.forEach((row, rowIndex) => {
    const rowValues = Object.values(row);
    rowValues.forEach((value, columnIndex) => {
      const cell = worksheet.getCell(rowIndex + dataRowStartIndex, columnIndex + 1);
      cell.value = value;
      cell.alignment = { horizontal: 'center' };
      const valueLength = String(value).length;
      const currentWidth = worksheet.getColumn(columnIndex + 1).width;
      const newWidth = Math.max(valueLength + columnWidthPadding, currentWidth);
      worksheet.getColumn(columnIndex + 1).width = newWidth;
      cell.border = {
        top: { style: 'thin', color: { argb: 'B2BEB5' } },
        left: { style: 'thin', color: { argb: 'B2BEB5' } },
        bottom: { style: 'thin', color: { argb: 'B2BEB5' } },
        right: { style: 'thin', color: { argb: 'B2BEB5' } },
      };
    });
  });
};

const searchReports = {
  controller: async (req, res) => {
    try {
      const { searchValue, role, timeRange, start_date, end_date } = req.query;

      let searchResults;
      switch (role) {
        case "all" || "":
        searchResults = await reports_services.getAllroleSubmission(timeRange, searchValue, start_date, end_date);

          break;
        case "account_manager":
          searchResults = await reports_services.get_AM_WithSubmissions(timeRange, searchValue, start_date, end_date);
          break;
        case "team_lead":
          searchResults = await reports_services.get_TL_WithSubmissions(timeRange,searchValue, start_date, end_date);
          break;
        case "recruiter":
          searchResults = await reports_services.getRecruitersWithSubmissions(timeRange,searchValue, start_date, end_date);
          break;
        default:
          searchResults = await reports_services.getAllroleSubmission(timeRange, searchValue, start_date, end_date);

          // res.status(400).json({ message: "Invalid role" });
          break;
      }

      res.status(200).json({ message: "Search is done!", data: searchResults });
    } catch (err) {
      console.log(err)
      res.status(500).json(err);
    }
  }
};








const downloadOverallPerformance = {
  controller: async (req, res) => {
    try {
      const role = req.query.role;
      const timeRange = req.query.timeRange;

      let AMData = [];
      let TLData = [];
      let RecData = [];

      switch (role) {
        case 'account_manager':
          AMData = await reports_services.get_AM_WithSubmissions(timeRange);
          break;
        case 'team_lead':
          TLData = await reports_services.get_TL_WithSubmissions(timeRange);
          break;
        case 'recruiter':
          RecData = await reports_services.getRecruitersWithSubmissions(timeRange);
          break;
        default:
          [AMData, TLData, RecData] = await Promise.all([
            reports_services.get_AM_WithSubmissions(timeRange),
            reports_services.get_TL_WithSubmissions(timeRange),
            reports_services.getRecruitersWithSubmissions(timeRange)
          ]);

      }


      const workbook = new Excel.Workbook();

      let accountManagerData = AMData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id,
          'Name': `${item.employee.first_name} ${item.employee.last_name} `,
          'Reports to': item.employee.reports_to ?` ${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name}  `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });

      let teamLeadData = TLData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id, 
          'Name':` ${item.employee.first_name} ${item.employee.last_name}`,
          'Reports to': item.employee.reports_to ?` ${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name} `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });

      let RecruiterData = RecData.map(item => {
        let transformed = {
          'Employee ID': item.employee.employee_id, 
          'Name': `${item.employee.first_name} ${item.employee.last_name}`,
          'Reports to': item.employee.reports_to ? `${item.employee.reports_to.first_name} ${item.employee.reports_to.last_name} `: 'N/A',
          'Mobile': item.employee.mobile_number,
          'Email ID': item.employee.email,
          'Individual Count': item.submissionsCount || 0,
          'Team Count': item.sub_teamCount || 0,
          "createdAt": ISOdateToCustomDate(item?.createdAt),

        };
        return transformed;
      });
      if (role === 'account_manager' || !role) {
        const AMWorksheet = workbook.addWorksheet('Account Managers');

        applyStylesToWorksheet(AMWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: accountManagerData
        });
      }

      if (role === 'team_lead' || !role) {
        const TLWorksheet = workbook.addWorksheet('Team Lead');

        applyStylesToWorksheet(TLWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: teamLeadData
        });
      }

      if (role === 'recruiter' || !role) {
        const RecruiterWorksheet = workbook.addWorksheet('Recruiter');

        applyStylesToWorksheet(RecruiterWorksheet, {
          client: ['Employee ID', 'Name', 'Reports to', 'Mobile', 'Email ID', 'Individual Count', 'Team Count'],
          value: RecruiterData
        });
      }

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=Overall_Performance.xlsx');


      await workbook.xlsx.write(res);


      // End the response
      res.end();
    } catch (error) {
      console.error('Error occurred while generating Excel:', error);
      res.status(500).send({ error: 'An error occurred while generating Excel file.' });
    }
  }
}
const get_AM_Reports = {
  controller: async (req, res) => {
    try {
      let timeRange = req.query.timeRange
      let searchValue = req.query.searchValue
      let start_date = req.query.start_date ? new Date(req.query.start_date) : null;
      let end_date = req.query.end_date ? new Date(req.query.end_date) : null;
      console.log(req.query, start_date, end_date, "start_date");
      

      let getEmployee = await reports_services.get_AM_WithSubmissions(timeRange, searchValue,start_date, end_date);

      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};

const get_TL_Reports = {
  controller: async (req, res) => {
    try {
      let timeRange = req.query.timeRange
      let searchValue = req.query.searchValue
      let start_date = req.query.start_date ? new Date(req.query.start_date) : null;
      let end_date = req.query.end_date ? new Date(req.query.end_date) : null;

      let getEmployee = await reports_services.get_TL_WithSubmissions(timeRange, searchValue,start_date, end_date); // Corrected method call

      
      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};




const getRecruitersReports = {
  controller: async (req, res) => {
    try {
      let timeRange = req.query.timeRange
      let searchValue = req.query.searchValue
      let start_date = req.query.start_date ? new Date(req.query.start_date) : null;
      let end_date = req.query.end_date ? new Date(req.query.end_date) : null;

      let getEmployee = await reports_services.getRecruitersWithSubmissions(timeRange, searchValue,start_date, end_date); // Corrected method call

      
      res.status(200).json({
        data: getEmployee,
        message: "All Employees fetched successfully",
      });
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  },
};

module.exports = {
  // getAllReports
  get_AM_Reports,get_TL_Reports,getRecruitersReports,downloadOverallPerformance,searchReports
};
