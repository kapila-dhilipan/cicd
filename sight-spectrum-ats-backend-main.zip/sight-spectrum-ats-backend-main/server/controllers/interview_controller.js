const interview_services = require("../services/interview_services")

const scheduleMeet = {
    controller: async (req, res) => {
        try {
            let new_obj = { ...req.body };
            new_obj["created_by"] = req.auth.user_id;
            const meetID = await interview_services.generateMeetingID();
            new_obj["MeetID"] = meetID;
            let schedule_meet = await interview_services.createMeet(new_obj);
            res.status(200).json({ message: 'Interview Scheduled successfully.', data: schedule_meet });
        } catch (error) {
            console.error("Error scheduling interview:", error);
            res.status(500).json({ error: 'An error occurred while scheduling interview.' });
        }
    },
};

const statusTracker = {
    controller: async (req, res) => {
        try {
            const user_id = req.auth.user_id;
            const meetStatus = await interview_services.getMeetStatus(user_id);
            const changeStatus = await interview_services.updateInterviewStatus(meetStatus)
            res.status(200).json({ message: 'schduled Data getdata.', data: changeStatus });
        } catch (err) {
            console.error("Erro while get Status Tracker: ", err)
            res.status(500).json({ err: 'An error occurred while Get Status.' });
        }
    }
}
const listInterview = {
    controller: async (req, res) => {
        let employees = await interview_services.listInterview(req.query)
        res.respond(employees, 200, 'Interview Details Fetched sucessfully');
    }
}

const getUserInterview = {
    controller: async (req, res) => {
        let demand = await interview_services.getUserCreatedInterview(req.auth.user_id, req.query)
        res.respond(demand, 200, 'Demands fetched sucessfully');
    }
}


const getUserInterviews = {
    controller: async (req, res) => {
        try {
            const userIdHierarchy = req.auth.user_id;
            const hierarchyUsers = await interview_services.getByReportsto(userIdHierarchy);

            const { skip, limit, sort_type, sort_field } = req.query;
            const interviews = await interview_services.getUserCreatedInterviews(userIdHierarchy, hierarchyUsers, { skip: parseInt(skip), limit: parseInt(limit), sort_type, sort_field });
            res.status(200).json(interviews);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
}

const interviewSearch = {
    controller: async (req, res) => {
        try {
            const ss = req.body.search;
            const searchvalue = await interview_services.getSearchValue(ss);
            res.status(200).json({ message: "search is done!", data: searchvalue })
        } catch (err) {
            console.error(err)
            res.status(500).json({ err: 'search error' });
        }
    }
}
const updateInterviewStatus = {
    controller: async (req, res) => {
        try {
            const Id = req.params.id;
            await interview_services.updateStatus(Id, req.body);
            console.log('requestbody', req.body)
            res.respond("Interview Status updated successfully", 200, 'Interview Status updated successfully.');
        } catch (error) {
            console.error(error);
            res.respond("Error updating interview status", 500, 'Error updating interview status');
        }
    }
}
module.exports = {
    scheduleMeet,
    listInterview,
    statusTracker,
    getUserInterview,
    interviewSearch,
    updateInterviewStatus,
    getUserInterviews
}